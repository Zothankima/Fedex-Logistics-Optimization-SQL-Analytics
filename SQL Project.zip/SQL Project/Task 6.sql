-- TASK 6 : Shipment Tracking Analytics

select * from shipments;
select shipment_id, order_id, agent_id, route_id, delivery_status, delivery_date from shipments order by delivery_date desc;
-- All 3 statuses are present across the 1000 shipments. the most recent shipments in the data go upto 2025, showing active ongoing operations across the network.

select s.route_id, r.source_city, r.destination_city, count(*) as total_shipments,
sum(case when s.delivery_status = 'In Transit' then 1 else 0 end) as in_transit,
sum(case when s.delivery_status = 'Returned' then 1 else 0 end) as returned,
sum(case when s.delivery_status = 'Delivered' then 1 else 0 end) as delivered,
round(100.0 * sum(case when s.delivery_status in ('In transit', 'returned') then 1 else 0 end) / count(*)), 2 as problem_pct
from shipments s inner join routes r on s.route_id = r.route_id group by s.route_id, r.source_city, r.destination_city having problem_pct > 50
order by problem_pct desc;
-- No route has more than 50% of shipments stuck in "In Transit" or "Returned" status, meaning the majority of shipments across all routes have been delivered. This is actually a positive finding.
-- While delays are widespread, shipments are eventually getting delivered across all routes.
-- No single route is critically blocked with unresolved shipments, which means the network is functioning but slowly rather than being completely broken.

select delay_reason, count(*) as frequency, round(100.0 * Count(*) / (select count(*) from shipments),2) as percentage
from shipments group by Delay_Reason order by frequency desc;
-- Traffic is by far the dominant delay cause at 48.6%, followed by Weather at 29.3%. Together they account for nearly 78% of all delays. 
-- Technical Issues at 16.8% are the only controllable internal factor — the rest are external. 
-- This means FedEx's optimization strategy should focus on better route scheduling to avoid traffic-heavy corridors and stronger contingency planning for weather disruptions rather than purely internal process fixes.

select s.shipment_id, s.order_id, s.route_id, r.source_city, r.destination_city, s.delay_hours, s.delay_reason, s.delivery_status
from shipments s inner join routes r on s.route_id = r.route_id where s.delay_hours > 120 order by s.delay_hours desc;
-- 52 shipments — about 5.2% of all shipments — experienced extreme delays exceeding 120 hours (5 days). The worst delay is 238.6 hours, nearly 10 days. 
-- Traffic is the most common reason even among extreme delays, appearing in the top cases. Notably, one shipment on R017 (S00490) with a 230.1-hour delay is still "In Transit"
-- Making it a critical bottleneck to investigate immediately. Routes R006, R011, R020, and R002 appear most frequently among extreme delay cases and should be flagged for priority operational review.