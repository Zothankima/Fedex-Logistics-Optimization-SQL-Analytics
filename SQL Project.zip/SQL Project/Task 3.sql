-- TASK 3 : Route Optimazation Insights
select * from shipments;
select * from routes;
Select s.route_id, r.source_city, r.destination_city, round(avg(timestampdiff(hour, s.pickup_date,s.delivery_date)),2) as avg_transit_hours
from shipments s inner join routes r on s.route_id = r.route_id
group by s.route_id,r.source_city,r.destination_city
order by s.route_id;
-- Avg Transit Time per Route Actual transit times exceed expected times on every route, indicating that the benchmark Avg_Transit_Time_Hours values in the system are outdated and need recalibration.

select s.route_id,r.source_city,r.destination_city, round(avg(s.delay_hours),2) as avg_delay_hours from shipments s inner join routes r
on s.route_id = r.route_id group by s.route_id,r.source_city, r.destination_city
order by avg_delay_hours desc;
-- Avg Delay per Route R002 (Dubai → Shanghai) has the highest average delay at 41.04 hours, while R001 (Memphis → Frankfurt) is the most reliable at just 6.83 hours. Routes involving Shanghai and Singapore consistently show the highest delays.

select *, round(distance_km/avg_transit_time_hours,2) as efficiency_ratio from routes order by efficiency_ratio desc;
--  Distance-to-Time Efficiency Ratio R019 (Johannesburg → Dubai) is the most efficient route with a ratio of 545.49, while R003 (Singapore → Hong Kong) is the least at 37.66, showing large inconsistencies in route planning across the network.

select *, round(distance_km/avg_transit_time_hours,2) as efficiency_ratio from routes order by efficiency_ratio asc limit 3;
-- 3 Worst Efficiency Routes R003, R015, and R006 are the worst performers — all three are relatively short routes but have disproportionately high transit times.

select s.route_id,r.source_city,r.destination_city, count(*) as total_shipments,
sum(case when timestampdiff(hour, s.pickup_date,s.delivery_date) > r.avg_transit_time_hours then 1 else 0 end) as delayed_beyond_expected,
round(100.0 * sum(case when timestampdiff(hour, s.pickup_date, s.delivery_date) > r.avg_transit_time_hours then 1 else 0 end) / count(*),2) as pct_delayed
from shipments s inner join routes r on s.Route_ID = r.Route_ID
group by s.route_id, r.source_city, r.destination_city, r.avg_transit_time_hours
having pct_delayed >20
order by pct_delayed desc;
-- Routes with >20% Shipments Exceeding Expected Transit All 20 routes exceed the 20% threshold, with R019 at 100% and R007 at 98%. This is a network-wide issue — either benchmarks are unrealistic or operational inefficiencies affect every corridor.

Select r.Route_ID,r.Source_City,r.Destination_City, round(r.Distance_KM / r.Avg_Transit_Time_Hours, 2) AS Efficiency_Ratio,
round(avg(s.Delay_Hours), 2) as Avg_Delay_Hours,
case 
when(r.Distance_KM / r.Avg_Transit_Time_Hours) < 110 and avg(s.Delay_Hours) > 20 
then 'HIGH PRIORITY'
when(r.Distance_KM / r.Avg_Transit_Time_Hours) < 200 and avg(s.Delay_Hours) > 25 
then 'MEDIUM PRIORITY'
else 'MONITOR'
end as Recommendation
FROM Routes r
JOIN Shipments s ON r.Route_ID = s.Route_ID
GROUP BY r.Route_ID, r.Source_City, r.Destination_City, r.Distance_KM, r.Avg_Transit_Time_Hours
ORDER BY Efficiency_Ratio ASC;
-- Routes are categorized into three priority levels based on their efficiency ratio and average delay:
-- High Priority : Route is both slow and highly delayed.
-- Medium Priority : Route has moderate inefficiency and notable delays.
-- Monitor :  Route is performing acceptably for now but should be tracked regularly.
