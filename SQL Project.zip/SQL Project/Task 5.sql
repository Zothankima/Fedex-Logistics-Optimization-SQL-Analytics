-- TASK 5 : Delivery Agent Performance
use project;
show tables;
select * from shipments;
select * from delivery;

select s.route_ID, s.agent_id, d.agent_name, count(*) as total_shipments,
sum( case when s.delay_hours = 0 then 1 else 0 end) as ontime_shipments,
round(100.0* sum( case when s.delay_hours = 0 then 1 else 0 end) / count(*), 2) as ontime_rate,
rank() over ( partition by s.route_id order by 100.0 * sum(case when s.delay_hours = 0 then 1 else 0 end) / count(*) desc) as rank_per_route
from shipments s inner join delivery d on s.agent_id = d.agent_id group by s.route_id, s.agent_id, d.agent_name order by s.route_id, rank_per_route;
--  On Route R001, Taylor Garcia and Mia Taylor both achieve 100% on-time but only handled 1 shipment each. Blake Martin handles 3 shipments at 33.3% — more representative.
-- Most agents across all routes score 0% on-time, confirming a systemic delay problem.

select s.agent_id, d.agent_name, d.zone, count(*) as total_shipments,
sum( case when s.delay_hours = 0 then 1 else 0 end) as ontime_shipments,
round(100.0 * sum(case when s.delay_hours = 0 then 1 else 0 end)/ count(*),2) as ontime_pct
from shipments s inner join delivery d on s.agent_id = d.agent_id group by s.agent_id, d.agent_name, d.zone order by ontime_pct desc;
-- All 49 agents in the dataset fall below the 85% threshold. The best performing agent — Taylor Garcia — only achieves 23.8% on-time.
-- This is not an individual agent problem, it reflects deeper route and operational issues affecting every agent in the network.

select 'Top 5' as group_label, round(avg(avg_rating),2) as avg_rating, round(avg(experience_years),1) as avg_exp_years
from delivery where agent_id IN ( select agent_id from ( select s.agent_id,100.0 * sum(case when s.delay_hours = 0 then 1 else 0 end)/ count(*) as ontime_pct
from shipments s group by s.agent_id order by ontime_pct desc limit 5) as top_agents)
Union all
select 'Bottom 5' as group_label, round(avg(avg_rating),2) as avg_rating, round(avg(experience_years),1) as avg_exp_years
from delivery where agent_id IN ( select agent_id from ( select s.agent_id,100.0 * sum(case when s.delay_hours = 0 then 1 else 0 end)/ count(*) as ontime_pct
from shipments s group by s.agent_id order by ontime_pct asc limit 5) as bottom_agents);
-- The top and bottom agents have almost identical ratings and experience. This confirms that individual agent skill is not the root cause of delays
-- The problem lies in route conditions, warehouse processing, and systemic operational issues beyond any single agent's control.

#Training Strategies : Since all agents fall below 85% on-time, blanket individual training won't solve the core issue.
-- Focus training on customs documentation handling and peak-period protocols since Weather, Traffic, and Technical Issues are the main delay reasons.
 -- Agents like Elliot Rodriguez, Cameron Lopez, and Jordan Jones with 0% on-time across multiple shipments should be prioritized for one-on-one performance review.
 #Workload Balancing : Agents handling high-delay routes like R002 (Dubai → Shanghai) and R007 (Shanghai → Sydney) should have reduced shipment loads during peak seasons to avoid burnout and further delays.
 -- Distribute shipments more evenly — some agents handle only 1–2 shipments per route while others handle 4+, creating inconsistent performance measurement.
 -- Pair low-performing agents with top performers like Taylor Garcia and Jamie Lopez on shared routes for on-the-job mentoring.

