-- TASK 2 : Delivery Delay Analysis
select* from shipments;
select shipment_id, Route_ID, Pickup_Date, Delivery_Date, timestampdiff(Hour, pickup_date, delivery_date) as Delivery_Delay_hours from shipments;
-- Delivery delay was calculated as the difference between Delivery_Date and Pickup_Date. I am using the TIMESTAMPDIFF() function because it is used to obtain the difference directly in hours.

select route_id, round(avg(delay_hours),2) as avg_delay_hours from shipments group by route_id order by avg_delay_hours desc limit 10;
-- The analysis identified the 10 routes with the highest average delay. These routes should be prioritized for operational review, as they contribute disproportionately to delivery inefficiencies and customer dissatisfaction.

select shipment_id,warehouse_id,delay_hours, rank() over(partition by warehouse_id order by delay_hours desc) as delay_rank from shipments;
-- A window function (RANK()) was used to rank shipments within each warehouse based on delay hours. Shipments with higher delays received higher priority rankings, helping identify warehouse-specific bottlenecks and operational issues.

select* from orders;
select*from shipments;
select o.delivery_type, avg(s.delay_hours) as Avg_delay_hours from orders o join shipments s on o.Order_ID = s.Order_ID group by o.Delivery_Type;
-- Express deliveries recorded a higher average delay (22.49 hours) compared to Standard deliveries (20.85 hours). This indicates potential inefficiencies in the Express delivery network and highlights an opportunity for operational improvement.

