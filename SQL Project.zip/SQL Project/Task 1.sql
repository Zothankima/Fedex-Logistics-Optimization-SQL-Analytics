CREATE DATABASE Project;
use project;
show tables;
rename table fedex_orders to orders;
rename table fedex_shipments to shipments;
rename table fedex_routes to routes;
rename table fedex_warehouses to warehouses;
rename table delivery_agents to delivery;
select * from delivery;
select * from orders;
select * from routes;
select * from shipments;
select * from warehouses;

-- TASK 1 : Data Cleaning & Preparation
Select order_id, count(*) from orders group by order_id having count(*)>1;
Select shipment_id, count(*) from shipments group by shipment_id having count(*)>1;
-- Since there is no duplicate in the above query there is nothing to delete so i skip the delete function.

select * from shipments where delay_hours is null;
-- Since there is no null or missing value in delay_hours column under shipments table, i skip the update function.

select order_date from orders;
-- Since the order_date from orders table is already in YYYY-MM-DD HH:MM:SS format, no conversion is needed.
select pickup_date from shipments;
-- Since the pickup_date from shipments table is already in YYYY-MM-DD HH:MM:SS format, no conversion is needed.
select delivery_date from shipments;
-- Since the delivery_date from shipments table is already in YYYY-MM-DD HH:MM:SS format, no conversion is needed.

select * from shipments where delivery_date < pickup_date;
-- No delivery_date occured before Pickup_date.

select o.order_id, o.route_id from orders o left join routes r on o.route_id = r.route_id where r.route_id is null;
-- Orders-->Routes table, referencial integrity is valid.
select o.order_id, o.warehouse_id from orders o left join warehouses w on o.warehouse_id = w.warehouse_id where w.warehouse_id is null;
-- Orders -->Warehouses table, referencial integrity is valid.
select s.shipment_id, s.order_id from shipments s left join orders o on s.order_id = o.order_id where o.order_id is null;
-- Shipments --> Orders table, referencial integrity is valid.
select s.shipment_id, s.route_id from shipments s left join routes r on s.route_id = r.route_id where r.route_id is null;
-- shipments --> Routes table, referencial integrity is valid.
select s.shipment_id, s.warehouse_id from shipments s left join warehouses w on s.warehouse_id = w.warehouse_id where w.warehouse_id is null;
-- shipments -- > warehouses table, referencial integrity is valid.

-- Referential integrity validation was performed using LEFT JOIN operations. No invalid records were found, confirming that all foreign key references across Orders, Routes, Warehouses, Shipments, and Delivery Agents were valid.
