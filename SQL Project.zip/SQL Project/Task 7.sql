-- TASK 7 : Advanced KPI Reporting

-- KPI 1 — Average Delivery Delay per Source Country
select r.source_country, count(*) as total_shipment, round(avg(s.delay_hours),2) as avg_delay_hours,
case when avg(s.delay_hours) > 30 then 'Critical'
when avg(s.delay_hours) > 20 then 'High'
when avg(s.delay_hours) > 10 then 'Moderate' else 'Low' end as delay_everity
from shipments s inner join routes r on s.route_id = r.route_id group by r.source_country order by avg_delay_hours desc;
-- UAE, Turkey, China, and Singapore are all Critical — shipments originating from these countries average over 30 hours of delay. Canada and Germany are the most reliable source countries with the lowest delays.

-- KPI 2 — Overall On-Time Delivery %
Select count(*) as Total_Deliveries,
sum(case when Delay_Hours = 0 then 1 else 0 end) as OnTime_Deliveries,
sum(case when Delay_Hours > 0 then 1 else 0 end) as Delayed_deliveries,
round(100.0 * sum(case when Delay_Hours = 0 then 1 else 0 end) / count(*),2) as ontime_pct,
round(100.0 * sum(case when Delay_Hours > 0 then 1 else 0 end) / count(*),2) as delayed_pct
from shipments;
-- Only 6.80% of all shipments are delivered on time — a critically low figure. 93.2% of shipments experience some level of delay, confirming a severe network-wide performance problem that goes beyond individual routes or agents.

-- KPI 3 — Average Delay per Route
select s.route_id, r.source_city, r.destination_city, count(*) as total_shipments, round(avg(s.delay_hours),2) as avg_delay_hours,
case when avg(s.delay_hours) > 30 then 'Critical'
when avg(s.delay_hours) > 20 then 'High'
when avg(s.delay_hours) > 10 then 'Moderate' else 'Low' end as delay_category
from shipments s inner join routes r on s.route_id = r.route_id group by  s.route_id, r.source_city, r.destination_city order by avg_delay_hours desc;
--  4 routes are in the Critical category, all involving Middle East and Asia Pacific corridors. R001 (Memphis → Frankfurt) remains the best performing route in the entire network at just 6.83 hours average delay.

-- KPI 4 - Warehouse Utilization %
select s.Warehouse_ID, w.City, w.Capacity_per_day, count(*) as Shipments_Handled,
round(100.0 * count(*) / w.Capacity_per_day, 2) as Utilization_Pct,
case
when 100.0 * count(*) / w.Capacity_per_day > 80 then 'Over Utilized'
when 100.0 * count(*) / w.Capacity_per_day > 50 then 'Well Utilized'
when 100.0 * count(*) / w.Capacity_per_day > 20 then 'Under Utilized' else'Critically Under Utilized' end as Utilization_Status
from Shipments s inner join Warehouses w on s.Warehouse_ID = w.Warehouse_ID group by s.Warehouse_ID, w.City, w.Capacity_per_day order by Utilization_Pct desc;
-- Every single warehouse is critically under utilized, the highest utilization is only 10.30% at Johannesburg. This means FedEx warehouse capacities are massively oversized relative to the current shipment volumes in this dataset.
-- Shipments are not being evenly distributed across available warehouse infastructure.