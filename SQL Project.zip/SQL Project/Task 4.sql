-- TASK 4 : Warehouse Performance

use project;
select * from shipments;
select * from warehouses;
select s.warehouse_id, w.city, w.country,
round( avg(s.delay_hours),2) as avg_delay_hours
from shipments s inner join warehouses w on s.warehouse_id = w.warehouse_id
group by s.warehouse_id, w.city, w.country
order by avg_delay_hours desc limit 3;
--  Shanghai leads in average delay, likely due to high shipment volumes and customs processing pressure. London and Amsterdam, both major European cargo hubs, also struggle with above-average delays.

select s.warehouse_id, w.city, count(*) as total_shipments,
sum( case when s.delay_hours>0 then 1 else 0 end) as delayed_shipments,
count(*) - sum( case when s.delay_hours>0 then 1 else 0 end) as ontime_shipments,
round(100.0 * sum( case when s.delay_hours>0 then 1 else 0 end)/ count(*),2) as delay_rate
from shipments s inner join warehouses w on s.warehouse_id = w.warehouse_id
group by s.warehouse_id, w.city order by delay_rate desc;
-- Tokyo is the worst performer with only 2 on-time shipments out of 96. Every warehouse has a delay rate above 90%, confirming this is a network-wide problem, not isolated to specific locations.

with global_avg as (
select round(avg(delay_hours),2) as global_avg_delay from shipments),
warehouse_avg as (
select s.warehouse_id, w.city, round(avg(s.delay_hours),2) as avg_delay from shipments s join warehouses w
on s.warehouse_id = w.warehouse_id group by s.warehouse_id, w.city)
select wa.warehouse_id, wa.city, wa.avg_delay, ga.global_avg_delay, round(wa.avg_delay - ga.global_avg_delay,2) as excess_delay
from warehouse_avg wa cross join global_avg ga where wa.avg_delay > ga.global_avg_delay
order by excess_delay desc;
-- 6 out 10 warehouses exceed the global average delay. Shanghai and London are the most concerning, each more than 4 hours above the global benchmark.

select s.warehouse_id, w.city, count(*) as total_shipments,
sum( case when s.delay_hours = 0 then 1 else 0 end) as ontime_shipments,
round(100.0 * sum( case when s.delay_hours = 0 then 1 else 0 end) / count(*),2) as ontime_rate,
rank() over(order by 100.0 * sum( case when s.delay_hours = 0 then 1 else 0 end) / count(*) desc) as ranking
from shipments s join warehouses w on s.warehouse_id = w.warehouse_id group by s.warehouse_id, w.city order by ranking;
-- Even the best warehouse Amsterdam only achieves 10.7% on-time delivery. Tokyo at 2.1% is critically underperforming.
-- These figures highlight that on-time delivery is failing across the entire warehouse network and requires urgent operational intervention.